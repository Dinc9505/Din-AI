import os
import openai
import base64
import json

OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
OPENAI_ORG = os.getenv('OPENAI_ORG')
MODEL_NAME = os.getenv('MODEL_NAME', 'gpt-4o-mini')

if OPENAI_API_KEY:
    openai.api_key = OPENAI_API_KEY
if OPENAI_ORG:
    openai.organization = OPENAI_ORG

MEMORY_FILE = '/tmp/dinc_ai_conversations.json'

def _load_memory():
    try:
        with open(MEMORY_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {}

def _save_memory(data):
    with open(MEMORY_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def chat_with_model(prompt: str, temperature: float = 0.2):
    if not OPENAI_API_KEY:
        return f"(stub) would call LLM with prompt: {prompt[:200]}..."
    resp = openai.ChatCompletion.create(
        model=MODEL_NAME,
        messages=[{'role':'user','content':prompt}],
        temperature=temperature,
    )
    return resp['choices'][0]['message']['content']

def chat_with_memory(user_id: str, user_message: str, retrieved_docs_text: str = '', temperature: float = 0.2):
    """Combines conversation memory and retrieved docs to form a context and call the LLM."""
    mem = _load_memory()
    conv = mem.get(user_id, [])
    # Build context: recent messages (up to last 6)
    recent = conv[-6:]
    system_ctx = "You are Dinç AI, a helpful assistant. Use the provided conversation history and retrieved documents to answer concisely."
    history_text = '\n'.join([f"{m['role']}: {m['text']}" for m in recent])
    retrieved_section = ('\n\nRelevant documents:\n' + retrieved_docs_text) if retrieved_docs_text else ''
    prompt = f"{system_ctx}\n\nConversation history:\n{history_text}\n\nUser: {user_message}\n\n{retrieved_section}\n\nAnswer:"
    reply = chat_with_model(prompt, temperature=temperature)
    # save to memory
    conv.append({'role':'user','text':user_message})
    conv.append({'role':'assistant','text':reply})
    mem[user_id] = conv[-1000:]  # cap size
    _save_memory(mem)
    return reply

def generate_image(prompt: str, size: str = '1024x1024'):
    if not OPENAI_API_KEY:
        return ''
    resp = openai.Image.create(
        prompt=prompt,
        n=1,
        size=size
    )
    data = resp['data'][0]
    if 'b64_json' in data:
        return data['b64_json']
    if 'url' in data:
        import requests
        r = requests.get(data['url'])
        return base64.b64encode(r.content).decode('utf-8')
    return ''
