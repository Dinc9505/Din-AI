import os
import requests
import openai

OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
ELEVENLABS_API_KEY = os.getenv('ELEVENLABS_API_KEY')
ELEVEN_VOICE_ID = os.getenv('ELEVEN_VOICE_ID', '21m00Tcm4TlvDq8ikWAM')

if OPENAI_API_KEY:
    openai.api_key = OPENAI_API_KEY

def transcribe_audio(file_bytes: bytes, filename='audio.wav'):
    # Use OpenAI Whisper API if available
    if not OPENAI_API_KEY:
        return '(stub) transcribed text'
    import io
    audio_file = io.BytesIO(file_bytes)
    audio_file.name = filename
    try:
        resp = openai.Audio.transcribe('whisper-1', audio_file)
        return resp['text']
    except Exception as e:
        return f'(error) {e}'

def synthesize_speech(text: str):
    # Use ElevenLabs text-to-speech API
    if not ELEVENLABS_API_KEY:
        return b''
    url = f'https://api.elevenlabs.io/v1/text-to-speech/{ELEVEN_VOICE_ID}'
    headers = {
        'xi-api-key': ELEVENLABS_API_KEY,
        'Content-Type': 'application/json'
    }
    payload = {
        'text': text,
        'voice_settings': {'stability': 0.5, 'similarity_boost': 0.75}
    }
    r = requests.post(url, headers=headers, json=payload)
    if r.status_code == 200:
        return r.content
    else:
        return b''
