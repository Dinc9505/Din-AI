import os
from langchain.document_loaders import PyPDFLoader, TextLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma

def extract_text_from_bytes(file_bytes: bytes, filename: str = 'file'):
    name = filename.lower()
    if name.endswith('.pdf'):
        import tempfile
        p = tempfile.NamedTemporaryFile(delete=False, suffix='.pdf')
        p.write(file_bytes)
        p.flush()
        loader = PyPDFLoader(p.name)
        docs = loader.load()
        texts = "\n\n".join([d.page_content for d in docs])
        return texts
    else:
        try:
            return file_bytes.decode('utf-8')
        except:
            return ''

def embed_and_store(text: str, collection_name='dinc'):
    emb = OpenAIEmbeddings()
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=800, chunk_overlap=100)
    docs = text_splitter.create_documents([text])
    vect = Chroma.from_documents(docs, embedding=emb, collection_name=collection_name)
    return {'status':'stored','count':len(docs)}

def similarity_search(query: str, collection_name='dinc', k=4):
    """Return top-k similar document texts from Chroma (if available)."""
    try:
        emb = OpenAIEmbeddings()
        vect = Chroma(collection_name=collection_name, embedding_function=emb)
        results = vect.similarity_search(query, k=k)
        return "\n---\n".join([r.page_content for r in results])
    except Exception as e:
        return ''
