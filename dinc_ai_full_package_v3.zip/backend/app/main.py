from fastapi import FastAPI, UploadFile, File, HTTPException, Request, Response
from pydantic import BaseModel
import uvicorn, io
from services import llm, embeddings, stt_tts

app = FastAPI(title='Dinc AI Backend')

class ChatReq(BaseModel):
    user_id: str
    message: str
    conversation_id: str = None

@app.get('/health')
def health():
    return {'status': 'ok'}

@app.post('/chat')
async def chat(req: ChatReq):
    try:
        # 1) retrieve from vectordb
        retrieved = embeddings.similarity_search(req.message)
        # 2) call memory-enabled chat
        reply = llm.chat_with_memory(req.user_id, req.message, retrieved_docs_text=retrieved)
        return {'reply': reply, 'retrieved': bool(retrieved)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post('/upload')
async def upload(file: UploadFile = File(...)):
    contents = await file.read()
    text = embeddings.extract_text_from_bytes(contents, filename=file.filename)
    out = embeddings.embed_and_store(text)
    return {'status': 'ok', 'filename': file.filename, 'stored': out}

@app.post('/stt')
async def stt(file: UploadFile = File(...)):
    audio_bytes = await file.read()
    text = stt_tts.transcribe_audio(audio_bytes)
    return {'text': text}

@app.post('/tts')
async def tts(payload: dict):
    text = payload.get('text')
    if not text:
        raise HTTPException(status_code=400, detail='text is required')
    audio_bytes = stt_tts.synthesize_speech(text)
    return Response(content=audio_bytes, media_type='audio/mpeg')

@app.post('/image')
async def image(payload: dict):
    prompt = payload.get('prompt')
    if not prompt:
        raise HTTPException(status_code=400, detail='prompt is required')
    img_b64 = llm.generate_image(prompt)
    return {'image_base64': img_b64}

if __name__ == '__main__':
    uvicorn.run(app, host='0.0.0.0', port=8000)
