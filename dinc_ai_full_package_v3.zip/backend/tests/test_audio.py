import requests, os, io

BASE = os.getenv('DINC_BASE', 'http://localhost:8000')

def test_stt_and_tts(sample_wav='sample_input.wav', out_mp3='output.mp3'):
    # 1) STT - upload wav
    with open(sample_wav, 'rb') as f:
        files = {'file': ('sample_input.wav', f, 'audio/wav')}
        r = requests.post(f'{BASE}/stt', files=files)
        print('STT status', r.status_code, r.text)
        text = r.json().get('text', '')
    # 2) TTS - generate speech from returned text
    if text:
        r2 = requests.post(f'{BASE}/tts', json={'text': text})
        if r2.status_code == 200:
            with open(out_mp3, 'wb') as out:
                out.write(r2.content)
            print('Saved TTS to', out_mp3)
        else:
            print('TTS failed', r2.status_code, r2.text)
    else:
        print('No text from STT to synthesize.')

if __name__ == '__main__':
    test_stt_and_tts()
