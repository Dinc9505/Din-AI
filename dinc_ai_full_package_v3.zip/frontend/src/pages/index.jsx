import {useState} from 'react'

export default function Home(){
  const [msg, setMsg] = useState('')
  const [reply, setReply] = useState('')
  const [prompt, setPrompt] = useState('')
  const [image, setImage] = useState(null)
  const [file, setFile] = useState(null)

  async function send(){
    const res = await fetch('http://localhost:8000/chat', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({user_id:'u1', message:msg})
    })
    const j = await res.json()
    setReply(j.reply || JSON.stringify(j))
  }

  async function genImage(){
    const res = await fetch('http://localhost:8000/image', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({prompt})
    })
    const j = await res.json()
    if(j.image_base64){
      setImage('data:image/png;base64,' + j.image_base64)
    }
  }

  async function upload(){
    if(!file) return
    const fd = new FormData()
    fd.append('file', file)
    const res = await fetch('http://localhost:8000/upload', {method:'POST', body: fd})
    const j = await res.json()
    alert('Uploaded: ' + JSON.stringify(j))
  }

  return (
    <div style={{padding:20, fontFamily:'Arial, sans-serif'}}>
      <h1>Dinç AI — Demo</h1>

      <h3>Chat</h3>
      <textarea value={msg} onChange={e=>setMsg(e.target.value)} rows={4} cols={60} />
      <br/>
      <button onClick={send} style={{marginTop:10}}>Gönder</button>
      <pre style={{whiteSpace:'pre-wrap', marginTop:10}}>{reply}</pre>

      <h3>Image generation</h3>
      <input value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder='Image prompt' style={{width:400}} />
      <button onClick={genImage}>Generate</button>
      {image && <div><img src={image} alt='generated' style={{maxWidth:400, marginTop:10}}/></div>}

      <h3>Upload document (PDF/TXT)</h3>
      <input type='file' onChange={e=>setFile(e.target.files[0])} />
      <button onClick={upload}>Upload</button>
    </div>
  )
}
