Dinç AI — Full Project Starter

Quick start:
1. Copy infra/.env.example to infra/.env and fill in API keys.
2. docker-compose up --build
3. Frontend: http://localhost:3000
   Backend:  http://localhost:8000
\n\n## Testing STT/TTS\nTo test STT/TTS locally after starting the backend:\n1. Install requests: `pip install requests`\n2. Run: `python backend/tests/test_audio.py`\nThis will upload `backend/tests/sample_input.wav` to `/stt` and then call `/tts` to save `output.mp3`.\n

## Testing STT/TTS
To test STT/TTS locally after starting the backend:
1. Install requests: `pip install requests`
2. Run: `python backend/tests/test_audio.py`
This will upload `backend/tests/sample_input.wav` to `/stt` and then call `/tts` to save `output.mp3`.
