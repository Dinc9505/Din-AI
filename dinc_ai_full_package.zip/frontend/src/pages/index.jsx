import {useState} from 'react'

export default function Home(){
  const [msg, setMsg] = useState('')
  const [reply, setReply] = useState('')

  async function send(){
    const res = await fetch('http://localhost:8000/chat', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({user_id:'u1', message:msg})
    })
    const j = await res.json()
    setReply(j.reply || JSON.stringify(j))
  }

  return (
    <div style={{padding:20, fontFamily:'Arial, sans-serif'}}>
      <h1>Dinç AI — Demo</h1>
      <textarea value={msg} onChange={e=>setMsg(e.target.value)} rows={6} cols={60} />
      <br/>
      <button onClick={send} style={{marginTop:10}}>Gönder</button>
      <pre style={{whiteSpace:'pre-wrap', marginTop:20}}>{reply}</pre>
    </div>
  )
}
