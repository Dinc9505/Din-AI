from fastapi import FastAPI, UploadFile, File
from pydantic import BaseModel
import uvicorn

app = FastAPI(title='Dinc AI Backend')

class ChatReq(BaseModel):
    user_id: str
    message: str

@app.get('/health')
def health():
    return {'status': 'ok'}

@app.post('/chat')
async def chat(req: ChatReq):
    # Placeholder: integrate LLM call in services/llm.py
    return {'reply': f"(stub) Dinç AI cevap: {req.message}"}

@app.post('/upload')
async def upload(file: UploadFile = File(...)):
    contents = await file.read()
    # Placeholder: extract text, embed, store in vector DB
    return {'status': 'ok', 'filename': file.filename}

if __name__ == '__main__':
    uvicorn.run(app, host='0.0.0.0', port=8000)
