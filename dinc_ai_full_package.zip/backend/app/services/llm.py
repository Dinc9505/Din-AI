# Simple wrapper for OpenAI calls (placeholder)
import os
import openai

OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
if OPENAI_API_KEY:
    openai.api_key = OPENAI_API_KEY

def simple_chat(prompt: str, temperature: float = 0.2):
    if not OPENAI_API_KEY:
        return f"(local stub) would call LLM with prompt: {prompt[:200]}..."
    resp = openai.ChatCompletion.create(
        model='gpt-4o-mini', # replace with available model
        messages=[{'role':'user','content':prompt}],
        temperature=temperature,
    )
    return resp['choices'][0]['message']['content']
