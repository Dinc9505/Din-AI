# Placeholder endpoints for STT/TTS integration
def transcribe_audio(file_bytes: bytes):
    # Integrate Whisper / other STT here
    return 'transcribed text (stub)'

def synthesize_speech(text: str):
    # Integrate ElevenLabs / gTTS here and return bytes of audio
    return b''  # empty bytes as stub
