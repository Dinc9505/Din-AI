Dinç AI — Full Project Starter

Quick start:
1. Copy infra/.env.example to infra/.env and fill in API keys.
2. docker-compose up --build
3. Frontend: http://localhost:3000
   Backend:  http://localhost:8000
